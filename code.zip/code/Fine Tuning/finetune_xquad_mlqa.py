from datasets import load_dataset
from transformers import DefaultDataCollator
from datasets import concatenate_datasets, DatasetDict
from transformers import AutoModelForQuestionAnswering, AutoTokenizer, TrainingArguments, Trainer, DefaultDataCollator
import numpy as np
from collections import defaultdict


data_collator = DefaultDataCollator()
langs = [ "de", "en", "es", "hi"]


mlqa = {}

for lang1 in langs:
    for lang2 in langs:
        mlqa[f"{lang1}.{lang2}"] = load_dataset("mlqa", f"mlqa.{lang1}.{lang2}",trust_remote_code=True)

    
def prepare_validation_features(examples):

    examples["question"] = [q.lstrip() for q in examples["question"]]

    tokenized_examples = tokenizer(
        examples["question"],
        examples["context"],
        truncation="only_second",
        max_length=max_length,
        stride=doc_stride,
        return_overflowing_tokens=True,
        return_offsets_mapping=True,
        padding="max_length",
    )


    sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")

    tokenized_examples["example_id"] = []

    for i in range(len(tokenized_examples["input_ids"])):
        sequence_ids = tokenized_examples.sequence_ids(i)
        context_index = 1
        
        sample_index = sample_mapping[i]
        tokenized_examples["example_id"].append(examples["id"][sample_index])

        tokenized_examples["offset_mapping"][i] = [
            (o if sequence_ids[k] == context_index else None)
            for k, o in enumerate(tokenized_examples["offset_mapping"][i])
        ]

    return tokenized_examples    

def prepare_train_features(examples):

    examples["question"] = [q.lstrip() for q in examples["question"]]
    tokenized_examples = tokenizer(
        examples["question"],
        examples["context"],
        truncation="only_second",
        max_length=max_length,
        stride=doc_stride,
        return_overflowing_tokens=True,
        return_offsets_mapping=True,
        padding="max_length",
    )


    sample_mapping = tokenized_examples.pop("overflow_to_sample_mapping")

    offset_mapping = tokenized_examples.pop("offset_mapping")

    tokenized_examples["start_positions"] = []
    tokenized_examples["end_positions"] = []

    for i, offsets in enumerate(offset_mapping):
        input_ids = tokenized_examples["input_ids"][i]
        cls_index = input_ids.index(tokenizer.cls_token_id)

        sequence_ids = tokenized_examples.sequence_ids(i)

        sample_index = sample_mapping[i]
        answers = examples["answers"][sample_index]
        if len(answers["answer_start"]) == 0:
            tokenized_examples["start_positions"].append(cls_index)
            tokenized_examples["end_positions"].append(cls_index)
        else:
            start_char = answers["answer_start"][0]
            end_char = start_char + len(answers["text"][0])

            token_start_index = 0
            while sequence_ids[token_start_index] != 1:
                token_start_index += 1

            token_end_index = len(input_ids) - 1
            while sequence_ids[token_end_index] != 1:
                token_end_index -= 1

            if not (offsets[token_start_index][0] <= start_char and offsets[token_end_index][1] >= end_char):
                tokenized_examples["start_positions"].append(cls_index)
                tokenized_examples["end_positions"].append(cls_index)
            else:

                while token_start_index < len(offsets) and offsets[token_start_index][0] <= start_char:
                    token_start_index += 1
                tokenized_examples["start_positions"].append(token_start_index - 1)
                while offsets[token_end_index][1] >= end_char:
                    token_end_index -= 1
                tokenized_examples["end_positions"].append(token_end_index + 1)

    return tokenized_examples


from tqdm.auto import tqdm
import collections
import numpy as np

def postprocess_qa_predictions(examples, features, raw_predictions, n_best_size = 20, max_answer_length = 30):
    all_start_logits, all_end_logits = raw_predictions
    example_id_to_index = {k: i for i, k in enumerate(examples["id"])}
    features_per_example = collections.defaultdict(list)
    for i, feature in enumerate(features):
        features_per_example[example_id_to_index[feature["example_id"]]].append(i)

    predictions = collections.OrderedDict()

    
    print(f"Post-processing {len(examples)} example predictions split into {len(features)} features.")

    for example_index, example in enumerate(tqdm(examples)):
        feature_indices = features_per_example[example_index]

        valid_answers = []
        
        context = example["context"]
        for feature_index in feature_indices:
            start_logits = all_start_logits[feature_index]
            end_logits = all_end_logits[feature_index]

            offset_mapping = features[feature_index]["offset_mapping"]

            start_indexes = np.argsort(start_logits)[-1 : -n_best_size - 1 : -1].tolist()
            end_indexes = np.argsort(end_logits)[-1 : -n_best_size - 1 : -1].tolist()
            for start_index in start_indexes:
                for end_index in end_indexes:

                    if (
                        start_index >= len(offset_mapping)
                        or end_index >= len(offset_mapping)
                        or offset_mapping[start_index] is None
                        or offset_mapping[end_index] is None
                    ):
                        continue
                    if end_index < start_index or end_index - start_index + 1 > max_answer_length:
                        continue

                    start_char = offset_mapping[start_index][0]
                    end_char = offset_mapping[end_index][1]
                    valid_answers.append(
                        {
                            "score": start_logits[start_index] + end_logits[end_index],
                            "text": context[start_char: end_char]
                        }
                    )
        
        if len(valid_answers) > 0:
            best_answer = sorted(valid_answers, key=lambda x: x["score"], reverse=True)[0]
        else:

            best_answer = {"text": "", "score": 0.0}
        
        predictions[example["id"]] = best_answer["text"]

    return predictions



model_name = "alon-albalak/xlm-roberta-base-xquad"
model = AutoModelForQuestionAnswering.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)


max_length = 384
doc_stride = 128

validation_datasets = []
for lang_pair, dataset in mlqa.items():
    if 'validation' in dataset:
        validation_datasets.append(dataset['validation'])
print("ge")
test_datasets = []
for lang_pair, dataset in mlqa.items():
    if 'test' in dataset:
        test_datasets.append(dataset['test'])

print("fd")
merged_train_dataset = concatenate_datasets(validation_datasets)
#merged_train_dataset = merged_train_dataset.select(range(100))

print("fdsfsdfsd")
# Merge test datasets for evaluation
merged_test_dataset = concatenate_datasets(test_datasets)

merged_test_dataset = merged_test_dataset.select(range(100))
print("fds")
# Process the merged datasets
train_processed = merged_train_dataset.map(
    prepare_train_features,
    batched=True,
    remove_columns=merged_train_dataset.column_names,
    desc="Processing training dataset",
)


test_processed = merged_test_dataset.map(
    prepare_validation_features,
    batched=True,
    remove_columns=merged_test_dataset.column_names,
    desc="Processing test dataset",
)

print(f"Training dataset size: {len(train_processed)}")
print(f"Test dataset size: {len(test_processed)}")


# Define training arguments
training_args = TrainingArguments(
    output_dir="./results",          
    evaluation_strategy="steps",    
    save_steps=500,                 
    eval_steps=500,                 
    logging_steps=100,              
    per_device_train_batch_size=8,  
    per_device_eval_batch_size=8,   
    learning_rate=3e-5,             
    num_train_epochs=3,            
    weight_decay=0.01,              
    save_total_limit=2,            
    fp16=True,                      
    dataloader_num_workers=4,       
    report_to="none"                
)

# Initialize the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_processed,
    eval_dataset=test_processed,
    data_collator=data_collator,  # Use the data collator defined earlier
    tokenizer=tokenizer           # Provide the tokenizer
)

# Start training
trainer.train()

# Save the fine-tuned model
model.save_pretrained("./fine_tuned_model")
tokenizer.save_pretrained("./fine_tuned_model")

print("Model fine-tuned and saved.")


from collections import defaultdict

mlqa_prep = defaultdict(dict)

def map_datasets(langs, split, prepare_features):
    for lang in langs:
        print(lang)
        mlqa_prep[lang][split] = mlqa[lang][split].map(prepare_features, batched=True, 
                                    remove_columns=mlqa[lang][split].column_names)

from evaluate import load

squad_metric = load("squad")

def compute_results(langs, split):
    results = {}
    for lang in langs:
        # We can grab the predictions for all features by using the method
        print(lang,langs)
        raw_predictions = trainer.predict(mlqa_prep[lang][split])

        # example_id and offset_mapping which we will need for our post-processing
        mlqa_prep[lang][split].set_format(type=mlqa_prep[lang][split].format["type"], 
                        columns=list(mlqa_prep[lang][split].features.keys()))
        
        # And we can apply our post-processing function to our raw predictions
        final_predictions = postprocess_qa_predictions(mlqa[lang][split], mlqa_prep[lang][split], raw_predictions.predictions)

        # We just need to format predictions and labels a bit as it expects a list of dictionaries and not one big dictionary.
        formatted_predictions = [{"id": k, "prediction_text": v} for k, v in final_predictions.items()]
        references = [{"id": ex["id"], "answers": ex["answers"]} for ex in mlqa[lang][split]]
        results[lang] = squad_metric.compute(predictions=formatted_predictions, references=references)
    return results


import pandas as pd

def results_df(results_dict, model):
    F1colname = "F1_" + model
    EMcolname = "EM_" + model
    dict_results = defaultdict(list)
    for lang, scores in results_dict.items():
        dict_results["lang"].append(lang)
        dict_results[F1colname].append(scores['f1'])
        dict_results[EMcolname].append(scores['exact_match'])

    avg_f1 = np.average(dict_results[F1colname])
    avg_em = np.average(dict_results[EMcolname])
    dict_results["lang"].append('avg')
    dict_results[F1colname].append(avg_f1)
    dict_results[EMcolname].append(avg_em)
    df_results = pd.DataFrame(dict_results).round(2)
    return df_results

from transformers import AutoModelForQuestionAnswering, AutoTokenizer

# Path to the saved fine-tuned model
model_path = "/kaggle/input/notebook6adfc3a3d7/fine_tuned_model/"

# Load the model and tokenizer
model = AutoModelForQuestionAnswering.from_pretrained(model_path)
tokenizer = AutoTokenizer.from_pretrained(model_path)

training_args = TrainingArguments(
    output_dir="xlm-roberta-large-xquad",
    report_to="none"                # Disable reporting to external tracking systems
)

trainer = Trainer(
    model=model,
    args=training_args,
    tokenizer=tokenizer,
    data_collator=data_collator,
)

# Load the evaluation metric
from evaluate import load
squad_metric = load("squad")

langs = ["de.de", "en.en", "es.es", "hi.hi"]
split = "test"

map_datasets(langs, split, prepare_validation_features)


# Compute results for validation datasets
validation_results = compute_results(langs, split)

# Convert results to a DataFrame for better visualization
df_validation_results = results_df(validation_results, "fine_tuned_model")
print(df_validation_results)



df_validation_results.to_csv("results_fine_tuning_xquad_mlqa_xlm_r.csv")
df_validation_results




